package com.example.romancalc;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    Button btn_1, btn_2;
    EditText et_number, et_romaninput;
    TextView tv_romanoutput, tv_numberoutput;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btn_1 = (Button) findViewById(R.id.btn_1);
        btn_2 = (Button) findViewById(R.id.btn_2);
        et_number = (EditText) findViewById(R.id.et_number);
        et_romaninput = (EditText) findViewById(R.id.et_romaninput);
        tv_numberoutput = (TextView)findViewById(R.id.tv_numberoutput);
        tv_romanoutput = (TextView)findViewById(R.id.tv_romanoutput);
        btn_1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                NumberConverter nc = new NumberConverter();

                int thenumber;
                String theroman;

                thenumber = Integer.parseInt(et_number.getText().toString());

                theroman = nc.toRoman(thenumber);
                 tv_romanoutput.setText(theroman);
            }
        });
        btn_2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });
    }
}