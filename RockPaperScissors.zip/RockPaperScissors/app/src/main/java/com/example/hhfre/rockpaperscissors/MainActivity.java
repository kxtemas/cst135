package com.example.hhfre.rockpaperscissors;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    Button b_rock, b_paper, b_scissors;
    TextView tv_score;
    ImageView iv_playerChoice, iv_cpuChoice;

    int playerScore, cpuScore = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //create variables and assign ID's that are in the layout
        b_rock = (Button) findViewById(R.id.b_rock);
        b_paper = (Button) findViewById(R.id.b_paper);
        b_scissors = (Button) findViewById(R.id.b_scissors);

        iv_playerChoice = (ImageView) findViewById(R.id.iv_playerChoice);
        iv_cpuChoice = (ImageView) findViewById(R.id.iv_cpuChoice);

        tv_score = (TextView) findViewById(R.id.tv_score);


        //on click listener events
        b_rock.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                iv_playerChoice.setImageResource(R.drawable.r);
                String message = play_turn("r");
                Toast.makeText(MainActivity.this, message, Toast.LENGTH_SHORT).show();
                tv_score.setText("Score: Player " + Integer.toString(playerScore) + " CPU " + Integer.toString(cpuScore));
            }
        });

        b_paper.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                iv_playerChoice.setImageResource(R.drawable.p);
                String message = play_turn("p");
                Toast.makeText(MainActivity.this, message, Toast.LENGTH_SHORT).show();
                tv_score.setText("Score: Player " + Integer.toString(playerScore) + " CPU " + Integer.toString(cpuScore));
            }
        });

        b_scissors.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                iv_playerChoice.setImageResource(R.drawable.s);
                String message = play_turn("s");
                Toast.makeText(MainActivity.this, message, Toast.LENGTH_SHORT).show();
                tv_score.setText("Score: Player " + Integer.toString(playerScore) + " CPU " + Integer.toString(cpuScore));
            }
        });
    }

    public String play_turn(String player_choice){
        //find cpu choice and set pic
        String cpu_choice = "";
        Random r = new Random();
        int cpu_choice_num = r.nextInt(3) + 1;
        if(cpu_choice_num == 1){
            cpu_choice = "r";
            iv_cpuChoice.setImageResource(R.drawable.r);
        }
        else if(cpu_choice_num == 2){
            cpu_choice = "p";
            iv_cpuChoice.setImageResource(R.drawable.p);
        }
        else{
            cpu_choice = "s";
            iv_cpuChoice.setImageResource(R.drawable.s);
        }

        //see who wins
        if(player_choice == cpu_choice){
            return "Draw";
        }
        else if(player_choice == "r" && cpu_choice == "s"){
            playerScore++;
            return "Rock crushes scissors. Player wins";
        }
        else if(player_choice == "s" && cpu_choice == "r"){
            cpuScore++;
            return "Rock crushes scissors. CPU wins";
        }
        else if(player_choice == "p" && cpu_choice == "r"){
            playerScore++;
            return "Paper covers rock. Player wins";
        }
        else if(player_choice == "r" && cpu_choice == "p"){
            cpuScore++;
            return "Paper covers rock. CPU wins";
        }
        else if(player_choice == "s" && cpu_choice == "p"){
            playerScore++;
            return "Scissors cuts paper. Player wins";
        }
        else if(player_choice == "p" && cpu_choice == "s"){
            cpuScore++;
            return "Scissors cuts paper. CPU wins";
        }
        else{
            return "error";
        }
    }
}
