package com.example.hhfre.mathquiz;

import android.graphics.Color;
import android.os.CountDownTimer;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    Button btn_start, btn_answer0, btn_answer1, btn_answer2, btn_answer3;
    TextView tv_timeLeft, tv_question, tv_score,tv_message;
    ProgressBar progBar_timer;

    Game g = new Game();
    int secondsRemaining = 30;
    CountDownTimer timer = new CountDownTimer(30000, 1000) {
        @Override
        public void onTick(long millisUntilFinished) {
            secondsRemaining--;
            tv_timeLeft.setText(Integer.toString(secondsRemaining) + " sec");
            progBar_timer.setProgress(30 - secondsRemaining);
        }

        @Override
        public void onFinish() {
            btn_answer0.setEnabled(false);
            btn_answer1.setEnabled(false);
            btn_answer2.setEnabled(false);
            btn_answer3.setEnabled(false);
            double grade = Double.valueOf ((g.getNumberCorrect()) / Double.valueOf((g.getTotalQuestions() - 1)));
            if(grade >= .9) {
                tv_message.setText("Time's up! You got " + g.getNumberCorrect() + "/" + (g.getTotalQuestions() - 1) + ", an A! :))");
            }
            else if( grade < .9 && grade >= .8){
                tv_message.setText("Time's up! You got " + g.getNumberCorrect() + "/" + (g.getTotalQuestions() - 1) + ", a B! :)");
            }
            else if( grade < .8 && grade >= .7){
                tv_message.setText("Time's up! You got " + g.getNumberCorrect() + "/" + (g.getTotalQuestions() - 1) + ", a C :|");
            }
            else if( grade < .7 && grade >= .6){
                tv_message.setText("Time's up! You got " + g.getNumberCorrect() + "/" + (g.getTotalQuestions() - 1) + ", a D :(");
            }
            else if( grade < .6){
                tv_message.setText("Time's up! You got " + g.getNumberCorrect() + "/" + (g.getTotalQuestions() - 1) + ", an F :((");
            }

            Handler hand = new Handler();
            hand.postDelayed(new Runnable() {
                @Override
                public void run() {
                    btn_start.setVisibility(View.VISIBLE);
                    tv_question.setText("");
                    btn_answer0.setText("");
                    btn_answer1.setText("");
                    btn_answer2.setText("");
                    btn_answer3.setText("");
                }
            }, 4000);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btn_start = findViewById(R.id.btn_start);
        btn_answer0 = findViewById(R.id.btn_answer0);
        btn_answer1 = findViewById(R.id.btn_answer1);
        btn_answer2 = findViewById(R.id.btn_answer2);
        btn_answer3 = findViewById(R.id.btn_answer3);

        tv_timeLeft = findViewById(R.id.tv_timeLeft);
        tv_question = findViewById(R.id.tv_question);
        tv_score = findViewById(R.id.tv_score);
        tv_message = findViewById(R.id.tv_message);

        progBar_timer = findViewById(R.id.progBar_timer);

        tv_timeLeft.setText("0");
        tv_question.setText("");
        tv_message.setText("Press Start");
        tv_score.setText("0 pts");
        progBar_timer.setProgress(0);
        btn_start.setText("Start");

        View.OnClickListener startButtonCL = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Button start_button = (Button) v;
                start_button.setVisibility(View.INVISIBLE);
                secondsRemaining = 30;
                g = new Game();
                timer.start();
                btn_answer0.setEnabled(true);
                btn_answer1.setEnabled(true);
                btn_answer2.setEnabled(true);
                btn_answer3.setEnabled(true);
                nextTurn();

            }};
        btn_start.setOnClickListener(startButtonCL);

        View.OnClickListener answerButtonCL = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Button answer_button = (Button) v;

                int answerSelected = Integer.parseInt(answer_button.getText().toString());

                if(g.checkAnswer(answerSelected) == true){
                    btn_answer0.setTextColor(Color.GREEN);
                    btn_answer1.setTextColor(Color.GREEN);
                    btn_answer2.setTextColor(Color.GREEN);
                    btn_answer3.setTextColor(Color.GREEN);
                    btn_answer0.setGravity(Gravity.CENTER);
                    btn_answer1.setGravity(Gravity.CENTER);
                    btn_answer2.setGravity(Gravity.CENTER);
                    btn_answer3.setGravity(Gravity.CENTER);

                }
                else{
                    btn_answer0.setTextColor(Color.RED);
                    btn_answer1.setTextColor(Color.RED);
                    btn_answer2.setTextColor(Color.RED);
                    btn_answer3.setTextColor(Color.RED);
                    btn_answer0.setGravity(Gravity.CENTER);
                    btn_answer1.setGravity(Gravity.CENTER);
                    btn_answer2.setGravity(Gravity.CENTER);
                    btn_answer3.setGravity(Gravity.CENTER);
                }
                Handler handler = new Handler();
                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        btn_answer0.setTextColor(Color.BLACK);
                        btn_answer1.setTextColor(Color.BLACK);
                        btn_answer2.setTextColor(Color.BLACK);
                        btn_answer3.setTextColor(Color.BLACK);
                        btn_answer0.setGravity(Gravity.CENTER);
                        btn_answer1.setGravity(Gravity.CENTER);
                        btn_answer2.setGravity(Gravity.CENTER);
                        btn_answer3.setGravity(Gravity.CENTER);


                    }
                }, 250);
                tv_score.setText(Integer.toString(g.getScore()) + " pts");
                nextTurn();
            }};
        btn_answer0.setOnClickListener(answerButtonCL);
        btn_answer1.setOnClickListener(answerButtonCL);
        btn_answer2.setOnClickListener(answerButtonCL);
        btn_answer3.setOnClickListener(answerButtonCL);
    }

    private void nextTurn(){
        //create new question
        g.makeNewQuestion();
        int[] answers = g.getCurrentQuestion().getAnswerArray();
        btn_answer0.setText(Integer.toString(answers[0]));
        btn_answer1.setText(Integer.toString(answers[1]));
        btn_answer2.setText(Integer.toString(answers[2]));
        btn_answer3.setText(Integer.toString(answers[3]));
        tv_question.setText(g.getCurrentQuestion().getQuestionPhrase());
        tv_message.setText(g.getNumberCorrect() + "/" + (g.getTotalQuestions() - 1));



    }
}
