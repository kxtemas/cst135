package com.example.hhfre.mathquiz;

import java.util.Random;

public class Question {

    private int firstNumber;
    private int secondNumber;
    private int answer;
    private int [] answerArray;
    private int answerPosition;
    private int upperLimit;

    private String questionPhrase;

    //generate a new random question
    public Question(int upperLimit){
        this.upperLimit = upperLimit;
        Random rnd = new Random();

        this.firstNumber = rnd.nextInt(upperLimit);
        this.secondNumber = rnd.nextInt(upperLimit);
        this.answer = this.firstNumber + this.secondNumber;
        this.questionPhrase = firstNumber + " + " + secondNumber + " = ___";

        this.answerPosition = rnd.nextInt(4);
        this.answerArray = new int[]{0,1,2,3};

        do {
            this.answerArray[0] = answer + rnd.nextInt(20) + 1;
            this.answerArray[1] = answer - rnd.nextInt(20) - 1;
            this.answerArray[2] = answer + rnd.nextInt(5) + 1;
            this.answerArray[3] = answer - rnd.nextInt(5) - 1;
        }
        while(this.answerArray[0] == this.answerArray[1] || this.answerArray[0] == this.answerArray[2] || this.answerArray[0] == this.answerArray[3]
                || this.answerArray[1] == answerArray[2] || this.answerArray[1] == answerArray[3] || this.answerArray[2] == answerArray[3]
                || this.answerArray[0] == answer || this.answerArray[1] == answer || this.answerArray[2] == answer || this.answerArray[3] == answer);

        this.answerArray = shuffleArray(this.answerArray);

        answerArray[answerPosition] = answer;
    }

    private int[] shuffleArray(int[] array){
        int index, temp;
        Random rnd = new Random();

        for (int i = array.length - 1; i > 0; i--){
            index = rnd.nextInt(i + 1);
            temp = array[index];
            array[index] = array[i];
            array[i] = temp;
        }
        return array;
    }

    //getters & setters
    public int getFirstNumber() {
        return firstNumber;
    }

    public void setFirstNumber(int firstNumber) {
        this.firstNumber = firstNumber;
    }

    public int getSecondNumber() {
        return secondNumber;
    }

    public void setSecondNumber(int secondNumber) {
        this.secondNumber = secondNumber;
    }

    public int getAnswer() {
        return answer;
    }

    public void setAnswer(int answer) {
        this.answer = answer;
    }

    public int[] getAnswerArray() {
        return answerArray;
    }

    public void setAnswerArray(int[] answerArray) {
        this.answerArray = answerArray;
    }

    public int getAnswerPosition() {
        return answerPosition;
    }

    public void setAnswerPosition(int answerPostion) {
        this.answerPosition = answerPostion;
    }

    public int getUpperLimit() {
        return upperLimit;
    }

    public void setUpperLimit(int upperLimit) {
        this.upperLimit = upperLimit;
    }

    public String getQuestionPhrase() {
        return questionPhrase;
    }

    public void setQuestionPhrase(String questionPhrase) {
        this.questionPhrase = questionPhrase;
    }
}
